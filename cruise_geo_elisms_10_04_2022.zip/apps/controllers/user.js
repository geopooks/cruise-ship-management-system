var helper = require("../helpers/helper");
var login_md = require('../models/login');
var package_md = require('../models/package');
var express = require("express");
var router = express.Router();
console.log("welcome");

router.get('/index', function (err, res) {
    res.render("user/index");
})
router.get('/search', function (err, res) {
   
    res.render("user/search", { data: ''});
})

router.get('/package_details1', function (err, res) {
    res.render("user/package_details1");
})

router.post("/search", function(req, res){

    var formvals = req.body;
     var searchval =  formvals.pkg;
    //  var shop =  formvals.shop;
     console.log(searchval);
    // var categoryval =  formvals.category; 

      var data = package_md.PackageSearch(searchval);
     // console.log("CATTTTTTT" +  JSON.stringify(data));
    //   var cdata = category_md.getAllcat();
      data.then(function (pack) {
        var data = {
            pack: pack,
            error: false
        };
        console.log("CATTTTTTT" +  JSON.stringify(data));
    //    cdata.then(function (category) {
    //   var cdata = {
    //       category : category,
    //       error: false
    //   };
     
      res.render("user/search", { data: data});
  }).catch(function (err) {
      res.render("user/search", { data: { error: "Get Post data is Error" } });
});
// res.render("web/index1");
});

//------------------------------------------------------------------------------------
//View Images
//------------------------------------------------------------------------------------

router.get('/gallery', function (req, res) {
    if (req.session.user) {
        // res.json({"message": "This is Operator Page"});
        var data = package_md.getfoto();
        console.log(data);
        data.then(function (user) {
            var data = {
                user: user,
                error: false
            };
            res.render("user/gallery", { data: data });
        }).catch(function (err) {
            res.render("user/gallery", { data: { error: "Get Post data is Error" } });
        });
    } else {
        res.redirect("user/gallery");
    }
});





//-------------------------------------------------------------------------------------
//View Luxury
//-------------------------------------------------------------------------------------

router.get('/luxury', function (req, res) {
        if (req.session.user) {
            // res.json({"message": "This is Operator Page"});
            var data = package_md.getluxury();
            console.log(data);
            data.then(function (user) {
                var data = {
                    user: user,
                    error: false
                };
                res.render("user/luxury", { data: data });
            }).catch(function (err) {
                res.render("user/luxury", { data: { error: "Get Post data is Error" } });
            });
        } else {
            res.redirect("user/luxury");
        }
    });
    

//---------------------------------------------------------------------------------------------
//View Standard
//---------------------------------------------------------------------------------------------


router.get('/honeymoon', function (req, res) {
    if (req.session.user) {
        // res.json({"message": "This is Operator Page"});
        var data = package_md.gethoneymoon();
        console.log(data);
        data.then(function (user) {
            var data = {
                user: user,
                error: false
            };
            res.render("user/honeymoon", { data: data });
        }).catch(function (err) {
            res.render("user/honeymoon", { data: { error: "Get Post data is Error" } });
        });
    } else {
        res.redirect("user/honeymoon");
    }
});


//---------------------------------------------------------------------------------------------
//View Cheap
//---------------------------------------------------------------------------------------------


router.get('/family', function (req, res) {
    if (req.session.user) {
        // res.json({"message": "This is Operator Page"});
        var data = package_md.getfamily();
        console.log(data);
        data.then(function (user) {
            var data = {
                user: user,
                error: false
            };
                console.log(JSON.stringify(data));
            res.render("user/family", { data: data });
        }).catch(function (err) {
            res.render("user/family", { data: { error: "Get Post data is Error" } });
        });
    } else {
        res.redirect("user/family");
    }
});


//--------------------------------------------------------------------------------------
// Package Details
//--------------------------------------------------------------------------------------


router.get('/package_details/:p_id', function (req, res) {
    //var id=req.params.p_id;
    console.log('test');
    console.log(pid);
    if (req.session.user) {
        var pid=req.params.p_id;
        // res.json({"message": "This is tour operator Page"});
        var data = package_md.getpackdetails(pid);
        console.log(data);
        data.then(function (user) {
            
            var data = {
                user: user,
                pack: user[0].p_type,
                error: false
            };
           
            res.render("user/package_details", { data: data });
        }).catch(function (err) {
            res.render("user/package_details", { data: { error: "Get Post data is Error" } });
        });
    } else {
        res.redirect("/user/package_details");
    }
});


router.post('/package_details', function (req, res) {

  

    var ptype = req.body.morecount;
    var p_id=req.body.package_id;
    console.log(req.body);
    

   user= {

        p_type:ptype,
     
    };
console.log(user);
    package_md.postbook(user);
    res.render("user/book", { data:user,p_id:p_id });
     //res.redirect("/user/book");
});



//---------------------------------------------------------------------------------------
//book
//---------------------------------------------------------------------------------------
router.get('/book', function (err, res) {
    res.render("user/book");
})


router.post('/book', function (req, res) {
    console.log('boooooooooooookkkkkkkkkk'+req.body);
    console.log(JSON.stringify(req.body));
     
    var p_id=req.body.package_id;
 var package_rate = req.body.package_rate;
    var memtot = req.body.morecount;
    var dob = req.body.dob;
    var passport = req.body.passport;
    var cabins = req.body.cabins;
    var category = req.body.category;
    var mem_name = req.body.fname;
    var totamt = package_rate*memtot;
    // console.log(totamt);
    // console.log(memtot);
    // console.log(p_id);
    // console.log(dob);
    // console.log(passport);
    // console.log(cabins);
    // console.log(category);
    // console.log(mem_name);

    booking= {

        p_type:memtot,
        p_id:p_id,
    
       

    };

  
    console.log(booking);
    //   package_md.postbook(booking,mem_name,dob,passport);
        res.render("user/book", { data:booking,mcount:memtot,p_id:p_id,totamt:totamt });
         //res.redirect("/user/book");
    });

    router.post('/bookregister', function (req, res) {
        console.log('boooooooooooookkkkkkkkkk'+req.body);
        console.log(JSON.stringify(req.body));
    
        var memtot = req.body.morecounttot;
        console.log("lllllllllllllllllll  "+memtot);
        var p_id=req.body.package_id;
       // console.log("lllllllllllllllllll  "+p_id);
        var dob = req.body.dob;
        var passport = req.body.passport;
        var cabins = req.body.cabins;
        var category = req.body.category;
        var mem_name = req.body.fname;
    
        
        console.log(p_id);
        console.log(dob);
        console.log(passport);
        console.log(cabins);
        console.log(category);
        var uid = req.session.user.id;
        booking= {
    
            member_count:memtot,
            p_id:p_id,
            booked_by:uid,

           
    
        };
    
        bookingpage= {
    
            member_count:memtot,
            cabins:cabins,
            category:category,
            p_id:p_id,
            booked_by:uid,
           
    
        };
        var package_totamt = req.body.package_totamt;
        
        //console.log(user);
           package_md.postbook(booking,mem_name,dob,passport,bookingpage);
           // res.render("user/bookregister", { data:booking});
             res.redirect("/user/payment/"+package_totamt);
        });


  //----------------------------------------------------------------------
  //payment
  //----------------------------------------------------------------------      
    
  router.get('/payment/:id', function (req, res) {
      var amt = req.params.id;
      console.log(amt);

   res.render("user/payment", { amt });
})


//------------------------------------------------------------------------------------------
//Edit Profile
//------------------------------------------------------------------------------------------

router.get('/edit_profile', function (req, res) {
    console.log('test');
    console.log(profile_id);

    if (req.session.user) {
        var profile_id=req.session.user.id;
        // res.json({"message": "This is tour operator Page"});
        var data = login_md.getuserprofile(profile_id);
        console.log(data);
        data.then(function (user) {
            var data = {
                user: user,
                error: false
            };
            res.render("user/edit_profile", { data: data });
        }).catch(function (err) {
            res.render("user/edit_profile", { data: { error: "Get Post data is Error" } });
        });
    } else {
        res.redirect("/user/edit_profile");
    }
});

router.post('/edit_profile', function (req, res) {
    // await multi_upload(req, res);
    // //console.log(req.files);

    // if (req.files.length <= 0) {
    //   return res.send(`You must select at least 1 file.`);
    // }

    var first_name = req.body.first_name;
    var last_name = req.body.last_name;
    var dob = req.body.dob;
    var email = req.body.email;
    var password= req.body.password;
    var mobilenumber=req.body.mobilenumber;
    var address= req.body.address;
    var city= req.body.city;
    var state= req.body.state;
    var country= req.body.country;
    var id = req.session.user.id;
    // var photos = req.files;
    // photos.forEach(function(photo){

   user= {

        first_name:first_name,
        last_name:last_name,
        dob:dob,
        email:email,
        password:password,
        mobilenumber:mobilenumber,
        address:address,
        city:city,
        state:state,
        country:country,
        // photo:photo.filename,
        id:id,

       };

   login_md.updateuserprofile(user);
   res.render("user/index", { data:user });
    });
    // res.redirect("/toptr/edit_package");


 //-----------------------------------------------------------------------------------------
 //Special Offers
 //-----------------------------------------------------------------------------------------

 router.get('/offer', function (req, res) {
    var id=req.params.p_id;
    console.log('test');
    console.log(id);
    if (req.session.user) {
        var id=req.params.p_id;
        // res.json({"message": "This is tour operator Page"});
        var data = package_md.getoffer(id);
        console.log(data);
        data.then(function (user) {
            var data = {
                user: user,
                error: false
            };
            res.render("user/offer", { data: data });
        }).catch(function (err) {
            res.render("user/offer", { data: { error: "Get Post data is Error" } });
        });
    } else {
        res.redirect("/user/offer");
    }
});

//---------------------------------------------------------------------------------------------
//Booking History
//---------------------------------------------------------------------------------------------
router.get('/booking_history', function (req, res) {
    //var id=req.params.p_id;
    console.log('test');
   
    if (req.session.user) {
       var uid= req.session.user.id;
        // res.json({"message": "This is tour operator Page"});
        var data = package_md.gethistory(uid);
        console.log(data);
        data.then(function (user) {
            var data = {
                user: user,
                error: false
            };
            res.render("user/booking_history", { data: data });
        }).catch(function (err) {
            res.render("user/booking_history", { data: { error: "Get Post data is Error" } });
        });
    } else {
        res.redirect("/user/booking_history");
    }
});


router.get('/paymentResponse/:pid', function (req, res) {
var pid = req.params.pid;
console.log(pid);

            res.render("user/payment_success", { pid });
      
   
});

router.get('/booking_history_ind/:id', function (req, res) {
    var id=req.params.id;
    console.log('test');
   
        // res.json({"message": "This is tour operator Page"});
        var data = package_md.gethistory(id);
        console.log(data);
        data.then(function (user) {
            var data = {
                user: user,
                error: false
            };
            res.render("user/booking_history_ind", { data: data });
        }).catch(function (err) {
            res.render("user/booking_history_ind", { data: { error: "Get Post data is Error" } });
        });
    
});

//---------------------------------------------------------------------------------------------------
//Delete Booking History
//---------------------------------------------------------------------------------------------------

router.get('/deletepackage/:b_id', function (req, res) {
    if (req.session.user) {
        
        var opid =req.params.b_id;
        console.log(opid);
                // res.json({"message": "This is Operator Page"});
        var data = package_md.delpack(opid);
        
       
        res.redirect("/user/index");
    }
});


//--------------------------------------------------------------------------------------------------------------
//operator delete package
//--------------------------------------------------------------------------------------------------------------

// router.get('/delpack/:p_id', function (req, res) {
//     if (req.session.admin) {
        
//         var opid =req.params.p_id;
//         console.log(opid);
//                 // res.json({"message": "This is Operator Page"});
//         var data = package_md.delpck(opid);
        
       
//         res.redirect("/toptr/index");
//     }
// });

module.exports = router;