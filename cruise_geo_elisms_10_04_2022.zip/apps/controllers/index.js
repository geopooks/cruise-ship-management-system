var express = require("express");
var router = express.Router();
console.log("welcome");
router.use("/", require(__dirname + "/web"));
router.use("/admin", require(__dirname + "/admin"));
router.use("/user", require(__dirname + "/user"));
router.use("/toptr", require(__dirname + "/toptr"));
module.exports = router;
