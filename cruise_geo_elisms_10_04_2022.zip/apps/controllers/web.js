var helper = require("../helpers/helper");
var login_md = require('../models/login');
var express = require("express");
var router = express.Router();
console.log("welcome");

router.get('/', function (err, res) {
    res.render("web/index");
})

router.get('/about', function (err, res) {
res.render("web/about");
})

router.get('/contact', function (req, res) {
    res.render("web/contact");
})

router.get('/service', function (err, res) {
    res.render("web/service");
})

router.get('/gallery', function (req, res) {
    res.render("web/gallery");
})

router.get('/login', function (err, res) {
    res.render("web/login",{ data: {} });
})

router.get('/Registration', function (err, res) {
    res.render("web/Registration", { data: {} } );
})

// router.post('/login', function (req, res) {
//     //console.log(req.body);
//     //console.log(req.body.username);
//     var uname=req.body.username;
//     var pword=req.body.password;
//     console.log(uname);
//     console.log(pword);

//     user = {
//         email : uname,
//         password: pword,
        
//     };
//     login_md.addUser(user);

//  res.render("web/login", { data: {error: "Get Post data is Error",username:uname,password:pword} });
// })

router.post("/login", function (req, res) {
    var params = req.body;

    if (params.username.trim().length == 0) {
        res.render("web/login", { data: { error: "Please enter an email" } });
       
    } 
    else {
        var data = login_md.getUserByEmail(params.username);

        if (data) {
            data.then(function (users) {
                var user = users[0];

                var status = helper.compare_password(params.password, user.password);

                if (!status) {

                    res.render("web/login", { data: { error: "Password Wrong" } });

                } 
                else {
                    
                    console.log("userdetails"+user);
                    if(user.user_type=='cl')
                    {
                      req.session.admin = user;
                      res.redirect("/admin/index");
                    }
                    else if(user.user_type=='toptr')
                    {
                      req.session.admin = user;
                      res.redirect("/toptr/index");
                    }
                    else if(user.user_type=='user')
                    {
                      req.session.user = user;
                      res.redirect("/user/index");
                    }
                     console.log(user);

                    
                }
            });
        } else {
            res.render("web/login", { data: { error: "User not exists" } });
        }
    }
})

router.post('/Registration', function (req, res) {

    var fname=req.body.firstname;
    var lname=req.body.lastname;
    var email=req.body.email;
    var mnumber=req.body.mobilenumber;
    var addressproof=req.body.addressproof;
    var password=req.body.password;
    var proofid=req.body.proofid;
    var dob=req.body.dob;
    var address=req.body.address;
    var city=req.body.city;
    var state=req.body.state;
    var country=req.body.country;

    console.log(fname);
    console.log(lname);
    console.log(email);
    console.log(mnumber);
    console.log(addressproof);
    console.log(password);
    console.log(proofid);
    console.log(address);
    console.log(city);
    console.log(state);
    console.log(country);
    console.log(dob);
    

    var hpassword = helper.hash_password(password);

    user = {
    
        first_name: fname,
        last_name: lname,
        email:email,
        password:hpassword,
        address:address,
        city:city,
        state:state,
        country:country,
        mobilenumber:mnumber,
        dob:dob,
        addressproof:addressproof,
        proofid:proofid,
        user_type:'user',
        
    };
    login_md.addUser(user);


 res.render("web/Registration", { data: {error: "Get Post data is Error"} });
})

router.get('/logout',function(req,res){
    req.session.destroy();
   // res.locals.admin="";
    res.locals.user="";
    res.redirect('/');
  });

module.exports = router;
