var helper = require("../helpers/helper");
var login_md = require('../models/login');
var package_md = require('../models/package');
var admin_md = require('../models/admin');
const multi_upload = require("../middleware/upload");
var express = require("express");
var router = express.Router();
const {check,validationResult}=require('express-validator');
const { json } = require("express");
console.log("welcome");

router.get('/index', function (err, res) {
    res.render("toptr/index");
})


//------------------------------------------------------------------------------------//
//operator view packages
//-----------------------------------------------------------------------------------//
///////-----//////

router.get('/package', function (req, res) {
    if (req.session.admin) {
        // var toptr = req.params.id;
        // console.log(toptr);
        var opid =req.session.admin.id;
        console.log(opid);
                // res.json({"message": "This is Operator Page"});
        var data = package_md.addpackage(opid,opid);
        
        data.then(function (user) {
            var data = {
                user: user,
                error: false
            };
            res.render("toptr/package", { data: data });
        }).catch(function (err) {
            res.render("toptr/package", { data: { error: "Get Post data is Error" } });
        });
    } else {
        res.redirect("toptr/package");
    }
});

//-----------------------------------------------------------------------------------------------//
// add package
//-----------------------------------------------------------------------------------------------//
   
router.get("/add_package", function (err, res) {
    res.render("toptr/add_package");
})  


router.post("/add_package",async function (req, res) {


    await multi_upload(req, res);
    //console.log(req.files);

    if (req.files.length <= 0) {
      return res.send(`You must select at least 1 file.`);
    }

    var cname=req.body.cname;
    var p_name=req.body.p_name;
    var sploffer=req.body.sploffer;
    var port=req.body.port;
    var dest=req.body.dest;
    var d_date=req.body.d_date;
    var d_time=req.body.d_time;
    var a_date=req.body.a_date;
    var type=req.body.type;
    var p_type=req.body.p_type;
    var category=req.body.category;
    var cabins=req.body.cabins;
    var p_rate=req.body.p_rate;
  
    var desc=req.body.desc;
    var offervalid=req.body.offervalid;
    var sploffer=req.body.sploffer;
    var photos = req.files;
    var toptr_id=req.session.admin.id;
    
var ptype = '';
for(var p in p_type){
    console.log('typeeeeeeeee   '+p_type[p]);
     ptype += p_type[p]+',';
} 
var ctype = '';
for(var p in type){
    console.log('typeeeeeeeee   '+type[p]);
     ctype += type[p]+',';
}
var cat = '';
for(var p in category){
    console.log('typeeeeeeeee   '+category[p]);
     cat += category[p]+',';
}
var cab = '';
for(var p in cabins){
    console.log('typeeeeeeeee   '+cabins[p]);
     cab += cabins[p]+',';
}

    photos.forEach(function(photo){

    console.log(req.body);
    console.log(p_name);
    console.log(sploffer);
    console.log(port);
    console.log(dest);
    console.log(d_date);
    console.log(d_time);
    console.log(a_date);
    console.log(type);
    console.log(p_type);
    console.log(category);
    console.log(cabins);
    console.log(p_rate);
   
    console.log(desc);
    console.log(offervalid);
    console.log(sploffer);
    console.log(toptr_id);

            user = {
                c_name:cname,
                p_name: p_name,
                sploffer: sploffer,
                port:port,
                dest:dest,
                d_date:d_date,
                time:d_time,
                a_date:a_date ,
                type:ctype,
                p_type:ptype,
                category:cat ,
                cabins:cab ,
                p_rate:p_rate,
              
                pack_desc : desc,
                offervalid:offervalid,
                sploffer:sploffer,
                photo:photo.filename,
                added_by:toptr_id,
   
            };
            // console.log(user);
    
            package_md.getpackage(user);
        
         res.render("toptr/add_package",{ data: { error: "Please enter your name",user:user} });//port:port,dest:dest,d_date:d_date,d_time:d_time,a_date:a_date,category:category,cabins:cabins,p_rate:p_rate,packageimage:packageimage,desc:desc} });
        });
})


//---------------------------------------------------------------------------------//
//Edit_package
//--------------------------------------------------------------------------------//


router.get('/edit_package/:p_id', function (req, res) {
    var id=req.params.p_id;
    console.log('test');
    console.log(id);
    if (req.session.admin) {
        var id=req.params.p_id;
        // res.json({"message": "This is tour operator Page"});
        var data = package_md.getpack(id);
        console.log(data);
        data.then(function (user) {
            var data = {
                user: user,
                error: false
            };
            res.render("toptr/edit_package", { data: data });
        }).catch(function (err) {
            res.render("toptr/edit_package", { data: { error: "Get Post data is Error" } });
        });
    } else {
        res.redirect("/toptr/edit_package");
    }
});


router.post('/edit_package',async function (req, res) {

    await multi_upload(req, res);
    //console.log(req.files);

    if (req.files.length <= 0) {
      return res.send(`You must select at least 1 file.`);
    }

    var type = req.body.type;
    var p_rate = req.body.p_rate;
    var d_date = req.body.d_date;
    var time = req.body.time;
    var a_date = req.body.a_date;
    var p_id = req.body.p_id;
    var photos = req.files;
    photos.forEach(function(photo){

   user= {

        type:type,
        p_rate:p_rate,
        d_date:d_date,
        time:time,
        a_date:a_date,
        photo:photo.filename,
        p_id:p_id,
        
    };
console.log(user);
    package_md.updatepackage(user);
    res.render("toptr/index", { data:user });
    // res.redirect("/toptr/edit_package");
});

   })

   //---------------------------------------------------------------------------------------//
   //Delete packages//
   //--------------------------------------------------------------------------------------//

   router.get('/delpack/:p_id', function (req, res) {
    if (req.session.admin) {
        
        var opid =req.params.p_id;
        console.log(opid);
                // res.json({"message": "This is Operator Page"});
        var data = package_md.delpck(opid);
        
       
        res.redirect("/toptr/package");
    }
});
 


   //----------------------------------------------------------------------------------------//
   // Edit Profile
   //---------------------------------------------------------------------------------------//


   router.get('/edit_profile', function (req, res) {
    console.log('test');
    console.log(profile_id);

    if (req.session.admin) {
        var profile_id=req.session.admin.id;
        // res.json({"message": "This is tour operator Page"});
        var data = admin_md.getprofile(profile_id);
        console.log(data);
        data.then(function (user) {
            var data = {
                user: user,
                error: false
            };
            res.render("toptr/edit_profile", { data: data });
        }).catch(function (err) {
            res.render("toptr/edit_profile", { data: { error: "Get Post data is Error" } });
        });
    } else {
        res.redirect("/toptr/edit_profile");
    }
});

router.post('/edit_profile',async function (req, res) {
    await multi_upload(req, res);
    //console.log(req.files);

    if (req.files.length <= 0) {
      return res.send(`You must select at least 1 file.`);
    }

    var first_name = req.body.first_name
    var last_name = req.body.last_name;
    var dob = req.body.dob;
    var email = req.body.email;
    var password= req.body.password;
    var mobilenumber=req.body.mobilenumber;
    var address= req.body.address;
    var city= req.body.city;
    var state= req.body.state;
    var country= req.body.country;
    var id = req.body.id;
    var photos = req.files;
    photos.forEach(function(photo){

   user= {

        first_name:first_name,
        last_name:last_name,
        dob:dob,
        email:email,
        password:password,
        mobilenumber:mobilenumber,
        address:address,
        city:city,
        state:state,
        country:country,
        photo:photo.filename,
        id:id,

       };

    admin_md.updateprofile(user);
    res.render("toptr/index", { data:user });
});
    // res.redirect("/toptr/edit_package");
 })

module.exports = router;