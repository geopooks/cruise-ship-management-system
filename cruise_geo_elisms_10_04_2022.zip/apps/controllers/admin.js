var helper = require("../helpers/helper");
var login_md = require('../models/login');
var admin_md = require('../models/admin');
var package_md = require('../models/package');
const multi_upload = require("../middleware/upload");
var express = require("express");
var router = express.Router();
const {check,validationResult}=require('express-validator');
const { json } = require("express");
console.log("welcome");

router.get('/index', function (err, res) {
    res.render("admin/index");
})

router.get('/login', function (err, res) {
    res.render("admin/login");
})
router.get('/register', function (err, res) {
    res.render("admin/register");
})




//----------------------------------------------------------------------------------------//

// admin view packages

//---------------------------------------------------------------------------------------//

router.get('/Packages/:id', function (req, res) {
    if(req.session.admin){
        var toptr = req.params.id;
        console.log(req.session.admin.email);
        console.log(req.session.admin.first_name);
        console.log(req.session.admin.last_name);
         // res.json({"message": "This is Admin Page"});

         var opid= req.session.admin.id;
         console.log('test');
         var data = package_md.addpackage(opid,toptr);
         console.log(data);
         data.then(function (user) {
             var data = {
                 user: user,
                 error: false
             };
             res.render("admin/Packages", { data: data });
         }).catch(function (err) {
             res.render("admin/Packages", { data: { error: "Get Post data is Error" } });
         });
     } else {
         res.redirect("admin/Packages");
     }
 });


//--------------------------------------------------------------------------------------//

//admin view user 

//--------------------------------------------------------------------------------------//


router.get('/user', function (req, res) {
    if (req.session.admin) {
        // res.json({"message": "This is Admin Page"});
        var data = admin_md.getuser();
        console.log(data);
        data.then(function (user) {
            var data = {
                user: user,
                error: false
            };
            res.render("admin/user", { data: data });
        }).catch(function (err) {
            res.render("admin/user", { data: { error: "Get Post data is Error" } });
        });
    } else {
        res.redirect("admin/user");
    }
});



//-----------------------------------------------------------------------------------------//

// admin view tour operator

//----------------------------------------------------------------------------------------//

 
router.get('/toptr', function (req, res) {
    if (req.session.admin) {
        // res.json({"message": "This is Admin Page"});
        var data = admin_md.getoptr();
        console.log(data);
        data.then(function (user) {
            var data = {
                user : user,
                error: false
            };
            res.render("admin/toptr", { data: data });
        }).catch(function (err) {
            res.render("admin/toptr", { data: { error: "Get Post data is Error" } });
        });
    } else {
        res.redirect("admin/toptr");
    }

});
//------------------------------------------------------------------------------
//delete operator
//------------------------------------------------------------------------------

router.get('/deletetoptr/:id', function (req, res) {
    if (req.session.admin) {
        
        var opid =req.params.id;
        console.log(opid);
                // res.json({"message": "This is Operator Page"});
        var data = admin_md.deleteoptr(opid);
        
       
        res.redirect("/admin/index");
    }
});



router.post('/login', function (req, res) {
    //console.log(req.body);
    //console.log(req.body.username);
    var uname=req.body.username;
    var pword=req.body.password;
    console.log(uname);
    console.log(pword);
user = {
                email : uname,
                password : pword,
            };
            login_md.addUser(user);
 
            res.render("web/login", { data: { error: "Please enter your username",username: uname,password: pword } });
})



router.post('/register', function (req, res) {

    var fname=req.body.firstname;
    var lname=req.body.lastname;
    var anumber=req.body.aadharnumber;
    var email=req.body.email;
    var password=req.body.password;
    
    var cname =req.body.cname;
    var mnumber=req.body.mobilenumber;
    var place =req.body.place;
    var state =req.body.state;
    
    console.log(fname);
    console.log(lname);
    console.log(anumber);
    console.log(email);
    console.log(password);
   
    console.log(cname);
    console.log(mnumber);
    console.log(place);
    console.log(state);

    

    var hpassword = helper.hash_password(password);

    user = {
    
        first_name: fname,
        last_name: lname,
        email:email,
        password:hpassword,
        user_type:'cl',
        
    };
    console.log(user);
    
    login_md.addUser(user);

 res.render("admin/register",{ data: { error: "Please enter your name",firstname:fname, lastname:lname, aadharnumber:anumber, email : email, password:password,  cname:cname, mobilenumber : mnumber, place:place , state:state} });
})

router.get('/admin/logout',function(req,res){
    req.session.destroy();
    res.locals.admin="";
    res.locals.user="";
    res.redirect('/web');
  });


  //----------------------------------------------------------------------------------------
  //Add operator
  //----------------------------------------------------------------------------------------


  router.get('/add_optr', function (err, res) {
    res.render("admin/add_optr");
})

  router.post('/add_optr',async function (req, res) {

    await multi_upload(req, res);
    //console.log(req.files);

    if (req.files.length <= 0) {
      return res.send(`You must select at least 1 file.`);
    }

    var optr_fname=req.body.optr_fname;
    var optr_lname=req.body.optr_lname;
    var dob=req.body.dob;
    var email=req.body.email;
    var password=req.body.password;
    var c_name=req.body.c_name;
    var optr_id=req.body.optr_id;
    var address=req.body.address;
    var city=req.body.city;
    var state=req.body.state;
    var country=req.body.country;
    var mobilenumber=req.body.mobilenumber;
    var addressproof=req.body.addressproof;
    var proofid=req.body.proofid;
    var photos = req.files;
    photos.forEach(function(photo){

    console.log(optr_fname);
    console.log(optr_lname);
    console.log(dob);
    console.log(email);
    console.log(password);
    console.log(c_name);
    console.log(optr_id);
    console.log(address);
    console.log(city);
    console.log(state);
    console.log(country);
    console.log(mobilenumber);
    console.log(addressproof);
    console.log(proofid);

    var hpassword = helper.hash_password(password);

    user = {
    
        first_name: optr_fname,
        last_name:optr_lname,
        dob:dob,
        email:email,
        password:hpassword,
        company_name:c_name,
        optr_id:optr_id,
        address:address,
        city:city,
        state:state,
        country:country,
        mobilenumber:mobilenumber,
        addressproof:addressproof,
        proofid:proofid,
        photo:photo.filename,
        user_type:'toptr',
        
    };
    admin_md.postoptr(user);
 res.render("admin/add_optr", { data: {error: "Get Post data is Error", user:user} });
});
})

//----------------------------------------------------------------------------------------------
//Gallery
//----------------------------------------------------------------------------------------------

router.get('/gallery', function (err, res) {
    res.render("admin/gallery");
})

router.post('/gallery',async function (req, res) {

    await multi_upload(req, res);
    //console.log(req.files);

    if (req.files.length <= 0) {
      return res.send(`You must select at least 1 file.`);
    }

    var photos = req.files;
    photos.forEach(function(photo){

        user = {
    
            images:photo.filename,
            
        };
        admin_md.postfoto(user);
     res.render("admin/gallery", { data: {error: "Get Post data is Error", user:user} });
    });
    })



module.exports = router;
