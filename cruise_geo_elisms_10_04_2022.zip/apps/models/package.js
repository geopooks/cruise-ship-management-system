var db = require("../common/database");
var q = require('q');

var conn = db.getConnection();

function addpackage(opid,toptr){
    var defer = q.defer();

    var query = conn.query('SELECT * FROM pack where added_by= '+ toptr, function(err, cate) {
        console.log(query);
        if(err){
            defer.reject(err);
        }else{
            defer.resolve(cate);
        }
    });

    return defer.promise;
}



function getpackage(user) {

    if (user) {
        var defer = q.defer();

        var query = conn.query('INSERT INTO pack SET ?', user, function (err, result) {
            console.log(query);
            if (err) {
                defer.reject(err);
            } else {
                defer.resolve(result);
            }
        });

        return defer.promise;
    }
    return false; 
}


//----------------------------------------------------------------------------------
//Update Package
//----------------------------------------------------------------------------------


function updatepackage(user) {

    if (user) {
        var defer = q.defer();
        var query = conn.query('UPDATE pack SET type = ?, p_rate = ? , d_date = ? ,time=? , a_date=? , photo=?  WHERE p_id= ? ',[user.type,user.p_rate, user.d_date,user.time, user.a_date,user.photo,user.p_id], function (err, result) {
            console.log(query);
            if (err) {
                defer.reject(err);
            } else {
                defer.resolve(result);
            }
        });

        return defer.promise;
    }
    return false;
}

function getpack(pid){
    var defer = q.defer();

    var query = conn.query('SELECT * FROM pack WHERE p_id='+pid, function(err, user) {
        console.log(query);
        if(err){
            defer.reject(err);
        }else{
            defer.resolve(user);
        }
    });

    return defer.promise;
}



//---------------------------------------------------------------------------------------
//View Luxury
//---------------------------------------------------------------------------------------

function getluxury(){
    var defer = q.defer();

    var query = conn.query("SELECT * FROM pack where type  LIKE '%1%'", function(err, cate) {
        console.log(query);
        if(err){
            defer.reject(err);
        }else{
            defer.resolve(cate);
        }
    });

    return defer.promise;
}


//---------------------------------------------------------------------------------------
//View Standard
//---------------------------------------------------------------------------------------

function gethoneymoon(){
    var defer = q.defer();

    var query = conn.query("SELECT * FROM pack where type  LIKE '%2%'", function(err, cate) {
        console.log(query);
        if(err){
            defer.reject(err);
        }else{
            defer.resolve(cate);
        }
    });

    return defer.promise;
}

//-------------------------------------------------------------------------------------
//View Cheap
//------------------------------------------------------------------------------------

function getfamily(){
    var defer = q.defer();

    var query = conn.query("SELECT * FROM pack where type  LIKE '%3%'", function(err, cate) {
        console.log(query);
        if(err){
            defer.reject(err);
        }else{
            defer.resolve(cate);
        }
    });

    return defer.promise;
}


//----------------------------------------------------------------------------------------
//Package Details
//----------------------------------------------------------------------------------------

function getpackdetails(pid){
    var defer = q.defer();

    var query = conn.query('SELECT * FROM pack WHERE p_id='+ pid , function(err, user) {
        console.log(query);
        if(err){
            defer.reject(err);
        }else{
            defer.resolve(user);
        }
    });

    return defer.promise;
}

//--------------------------------------------------------------------------------------------
//Booking
//--------------------------------------------------------------------------------------------


function postbook(bookings,mem_name,dob,passport,bookingpage) {

    console.log(JSON.stringify(mem_name));
    console.log(JSON.stringify(dob));
    console.log(JSON.stringify(passport));

    if (bookings) {
        var defer = q.defer();

        var query = conn.query('INSERT INTO booking SET ?', bookings, function (err, result) {
            console.log(query);
            if (err) {
                defer.reject(err);
            } else {
                var booking_id = result.insertId;

                let a = 0 ;
               var memcount = parseInt(mem_name.length);
               console.log('no of members '+memcount);
               if(memcount==1){
                var pack ='single';
            }

            console.log(bookingpage.member_count);


            if(bookingpage.member_count==1){
                var pack ='single';
                console.log('cccccccc'+pack); 
            }
            if(bookingpage.member_count==2){
                var pack ='couple';
                console.log('cccccccc'+pack);
            }
            if(bookingpage.member_count==4){
                var pack ='family';
                console.log('cccccccc'+pack);
            }

           
            bookingpage.member_count
            for(j=0;j<bookingpage.member_count;j++){
              //  mem_name.forEach(function(member){

                booking_det = {
                    booking_id:booking_id,
                    cabins:bookingpage.cabins,
                    category:bookingpage.category,
                    fname : mem_name,
                    dob:dob,
                    passport:passport,
                    p_type : pack,
                }
                var query = conn.query('INSERT INTO booking_details SET ?', booking_det, function (err, result) {
                    console.log(query);
                    if (err) {
                        defer.reject(err);
                    } else {
                        defer.resolve(result);
                    }
                });
        
                defer.resolve(result);
                a++;
             }
            }
        });

        return defer.promise;
    }
    return false; 
}




//-------------------------------------------------------------------------------------------
//Special Offer
//-------------------------------------------------------------------------------------------

function getoffer(){
    var defer = q.defer();

    var query = conn.query('SELECT * FROM pack WHERE offervalid = "y" ', function(err, cate) {
        console.log(query);
        if(err){
            defer.reject(err);
        }else{
            defer.resolve(cate);
        }
    });

    return defer.promise;
}


//--------------------------------------------------------------------------------------------
//View Gallery
//-------------------------------------------------------------------------------------------

function getfoto(){
    var defer = q.defer();

    var query = conn.query("SELECT * FROM pack ", function(err, cate) {
        console.log(query);
        if(err){
            defer.reject(err);
        }else{
            defer.resolve(cate);
        }
    });

    return defer.promise;
}


//--------------------------------------------------------------------------------------
//Booking History
//--------------------------------------------------------------------------------------

function gethistory(uid){
    var defer = q.defer();

    var query = conn.query('SELECT * FROM `booking`,booking_details,pack where booking.booking_id=booking_details.booking_id and booking.p_id=pack.p_id and booking.booked_by='+ uid , function(err, user) {
        console.log(query);
        if(err){
            defer.reject(err);
        }else{
            defer.resolve(user);
        }
    });

    return defer.promise;
}

//-----------------------------------------------------------------------------------------
//Search
//-----------------------------------------------------------------------------------------

function PackageSearch(pkg) {
    var defer = q.defer();

        var sql ='SELECT * FROM pack where pack.p_name  LIKE"%'+pkg+'%"';
        // if(shop){
        //     sql +=' and users.shop_name  LIKE"%'+shop+'%"  and users.user_type="seller"';
        // }
         sql +=' GROUP BY pack.p_id  ORDER BY p_rate ASC';
       var query = conn.query(sql, function (err, users) {
       console.log(query);
        if (err) {
            defer.reject(err);
        } else {
            defer.resolve(users);
        }
    });

    return defer.promise;
}

//-----------------------------------------------------------------------------------------------
//Delete booking history
//-----------------------------------------------------------------------------------------------

function delpack(id){
    if(id){
        var defer = q.defer();

        var query = conn.query('DELETE FROM booking WHERE booking_id = ? ', [id], function(err, result) {
           console.log(query);
            if(err){
                defer.reject(err);
            }else{
                defer.resolve(result);
            }
        });

        return defer.promise;
    }

    return false;
}

//--------------------------------------------------------------------------------------------------
//Delete package by tour operator
//--------------------------------------------------------------------------------------------------

function delpck(id){
    if(id){
        var defer = q.defer();

        var query = conn.query('DELETE FROM pack WHERE p_id = ? ', [id], function(err, result) {
           console.log(query);
            if(err){
                defer.reject(err);
            }else{
                defer.resolve(result);
            }
        });

        return defer.promise;
    }

    return false;
}

module.exports = {

    addpackage : addpackage,
    getpackage : getpackage,
    getpack:getpack,
    updatepackage: updatepackage,
    getluxury:getluxury,
    gethoneymoon:gethoneymoon,
    getfamily:getfamily,
    getpackdetails:getpackdetails,
    postbook:postbook,
    getoffer:getoffer,
    getfoto:getfoto,
    gethistory:gethistory,
    PackageSearch:PackageSearch,
    delpack:delpack,
    delpck:delpck,
   
   
   }