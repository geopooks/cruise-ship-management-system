var db = require("../common/database");
var q = require('q');

var conn = db.getConnection();

//admin view user

function getuser(){
    var defer = q.defer();

    var query = conn.query('SELECT * FROM users where user_type ="user" ', function(err, champ) {
      console.log(query);
        if(err){
            defer.reject(err);
        }else{
            defer.resolve(champ);
        }
    });

    return defer.promise;
}

//admin view operator

   function getoptr(){
    var defer = q.defer();

    var query = conn.query('SELECT * FROM users where user_type ="toptr"', function(err, cate) {
        console.log(query);
        if(err){
            defer.reject(err);
        }else{
            defer.resolve(cate);
        }
    });

    return defer.promise;
}



function postoptr(user) {

    if (user) {
        var defer = q.defer();

        var query = conn.query('INSERT INTO users SET ?', user, function (err, result) {
            console.log(query);
            if (err) {
                defer.reject(err);
            } else {
                defer.resolve(result);
            }
        });

        return defer.promise;
    }
    return false;
}


//-----------------------------------------------------------------------------
//Update Operator Profile
//-----------------------------------------------------------------------------

function getprofile(profile_id){
    var defer = q.defer();

    var query = conn.query('SELECT * FROM users WHERE id='+ profile_id, function(err, user) {
        console.log(query);
        if(err){
            defer.reject(err);
        }else{
            defer.resolve(user);
        }
    });

    return defer.promise;
}

function updateprofile(user) {

    if (user) {
        var defer = q.defer();
        var query = conn.query('UPDATE users SET  first_name = ? , last_name = ? ,dob = ? , email=? , password=? , mobilenumber = ?, address = ?, city = ? , state = ?, country = ? , photo = ? WHERE id= ? ',[user.first_name, user.last_name,user.dob, user.email,user.password,user.mobilenumber,user.address,user.city,user.state,user.country,user.photo,user.id], function (err, result) {
            console.log(query);
            if (err) {
                defer.reject(err);
            } else {
                defer.resolve(result);
            }
        });

        return defer.promise;
    }
    return false;
}

//----------------------------------------------------------------------------------------
//Gallery
//----------------------------------------------------------------------------------------

function postfoto(user) {

    if (user) {
        var defer = q.defer();

        var query = conn.query('INSERT INTO pack SET ?', user, function (err, result) {
            console.log(query);
            if (err) {
                defer.reject(err);
            } else {
                defer.resolve(result);
            }
        });

        return defer.promise;
    }
    return false;
}

//-------------------------------------------------------------------------------
//Delete tour operator
//-------------------------------------------------------------------------------


function deleteoptr(id){
    if(id){
        var defer = q.defer();

        var query = conn.query('DELETE FROM users WHERE id = ? ', [id], function(err, result) {
           console.log(query);
            if(err){
                defer.reject(err);
            }else{
                defer.resolve(result);
            }
        });

        return defer.promise;
    }

    return false;
}



module.exports = {
    getuser  : getuser,
    getoptr  : getoptr,
    postoptr : postoptr,
    getprofile:getprofile,
    updateprofile:updateprofile,
    postfoto:postfoto,
    deleteoptr:deleteoptr,
    
   }